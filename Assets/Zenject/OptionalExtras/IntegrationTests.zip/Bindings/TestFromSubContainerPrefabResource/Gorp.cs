using UnityEngine;

namespace Zenject.Tests.Bindings.FromSubContainerPrefabResource
{
    public class Gorp
    {
    }
}

